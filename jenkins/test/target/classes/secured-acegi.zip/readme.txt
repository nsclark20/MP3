Anonymous users have no permissions, logged in users can do anything.

Uses Jenkins user database, because 'Remember me' functionality requires non-legacy security realm to be enabled.
